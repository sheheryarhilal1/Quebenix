# Quebenix Technology POS

Responsive HTML, CSS and vanilla JavaScript POS demo.

## Features
- Dashboard and sales summary
- POS catalogue, cart, discount and tax
- Client and service management
- Sales history and printable invoices
- Expense tracking and reports
- CSV export and business settings

## Run locally
Open `index.html` in a browser, or use VS Code Live Server.

## Deploy
This is a static website, not a Streamlit Python app. Upload the extracted project to GitHub, then use GitHub Pages, Netlify or Cloudflare Pages. For GitHub Pages: Repository → Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.

## Data limitation
Records are stored in browser LocalStorage. They are not shared between devices or staff and are not suitable as a production database. For real business use, add a secure backend/cloud database, server-side authentication and backups. Do not store payment card data in this demo.
